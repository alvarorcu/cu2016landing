function miFuncion() {
                var x = document.getElementById("demo");
                x.style.fontSize = "25px";           
                x.style.color = "red"; 
            }